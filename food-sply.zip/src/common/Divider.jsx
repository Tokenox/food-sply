'use client';
import React from "react";

const Divider = () => {
  return <div className="bg-[#4E4E4E] h-[1px]" />;
};

export default Divider;
